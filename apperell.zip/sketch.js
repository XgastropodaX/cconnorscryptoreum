https://github.com/XgastropodaX/img/blob/main/cachow.mp3?raw=true
function playMusic(){
  var music = new Audio('https://github.com/XgastropodaX/img/blob/main/cachow.mp3?raw=true');
  music.play();
  }