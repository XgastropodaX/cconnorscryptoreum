function setup() {
  createCanvas(2100, 1520);
}


function draw() {
  background('black');
}
